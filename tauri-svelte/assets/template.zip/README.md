# project-name

description

## Why This Project

## Features

## Preview

## Download

Download installers from [Releases](https://github.com/xxx/xxx/releases):

- **macOS**: `project-name_x.x.x_aarch64.dmg` (Apple Silicon) / `project-name_x.x.x_x64.dmg` (Intel)
- **Windows**: `project-name_x.x.x_x64-setup.exe`

## Tech Stack

- **Tauri v2**
- **Svelte 5**
- **Vite**
- **Tailwind CSS**
- **Lucide Icons**

## Project Structure

- `src/`: Frontend core
- `src-tauri/`: Rust backend and packaging config
- `scripts/`: Release and maintenance scripts

## Development

### Prerequisites

- [Node.js](https://nodejs.org/) (recommended: 18+)
- [Rust](https://www.rust-lang.org/tools/install)
- [Tauri prerequisites](https://tauri.app/start/prerequisites/)

### Install dependencies

```bash
npm install
```

### Run locally

```bash
npm run tauri -- dev
```

### Build

```bash
npm run build
npm run tauri -- build
```

### Release

1. Edit the `[Unreleased]` section in [CHANGELOG.md](CHANGELOG.md) with the changes for this release
2. Run the release script:
   ```bash
   npm run release <version>
   ```
   Example: `npm run release 0.9.0`

### Development Rules

[AGENTS.md](AGENTS.md)

## Contributing

[CONTRIBUTING.md](CONTRIBUTING.md)

## License

MIT