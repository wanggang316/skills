use crate::services::todo_service::{TodoItem, TodoService};
use std::sync::Arc;

static TODO_SERVICE: once_cell::sync::OnceCell<Arc<TodoService>> = once_cell::sync::OnceCell::new();

fn get_service() -> Arc<TodoService> {
  TODO_SERVICE
    .get_or_init(|| Arc::new(TodoService::new()))
    .clone()
}

#[tauri::command]
pub fn add_todo(todo: TodoItem) -> Result<TodoItem, String> {
  let service = get_service();
  service.add_todo(todo)
}

#[tauri::command]
pub fn update_todo(todo: TodoItem) -> Result<Option<TodoItem>, String> {
  let service = get_service();
  service.update_todo(&todo.id.clone(), todo)
}

#[tauri::command]
pub fn delete_todo(id: String) -> Result<bool, String> {
  let service = get_service();
  service.delete_todo(&id)
}

#[tauri::command]
pub fn list_todos() -> Result<Vec<TodoItem>, String> {
  let service = get_service();
  service.list_todos()
}

#[tauri::command]
pub fn get_todo(id: String) -> Result<Option<TodoItem>, String> {
  let service = get_service();
  service.get_todo(&id)
}
