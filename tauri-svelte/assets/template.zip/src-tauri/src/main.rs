#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

mod commands;
mod services;
mod utils;

use commands::settings::{get_settings, update_settings};
use commands::todo::{add_todo, delete_todo, get_todo, list_todos, update_todo};

fn main() {
  tauri::Builder::default()
    .plugin(tauri_plugin_updater::Builder::new().build())
    .plugin(tauri_plugin_process::init())
    .invoke_handler(tauri::generate_handler![
      get_settings,
      update_settings,
      add_todo,
      update_todo,
      delete_todo,
      list_todos,
      get_todo
    ])
    .run(tauri::generate_context!())
    .expect("error while running tauri application");
}
