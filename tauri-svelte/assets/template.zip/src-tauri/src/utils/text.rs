pub fn normalize_name(input: Option<&str>) -> String {
  let value = input.unwrap_or("frontend").trim();
  if value.is_empty() {
    "frontend".to_string()
  } else {
    value.to_string()
  }
}
