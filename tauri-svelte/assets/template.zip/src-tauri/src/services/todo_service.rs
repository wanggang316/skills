use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::sync::{Arc, Mutex};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TodoItem {
  pub id: String,
  pub title: String,
  pub completed: bool,
  #[serde(default = "chrono_timestamp")]
  pub created_at: i64,
  #[serde(default = "chrono_timestamp")]
  pub updated_at: i64,
}

fn chrono_timestamp() -> i64 {
  use std::time::{SystemTime, UNIX_EPOCH};
  SystemTime::now()
    .duration_since(UNIX_EPOCH)
    .unwrap_or_default()
    .as_millis()
    .try_into()
    .unwrap()
}

#[derive(Debug, Clone)]
pub struct TodoService {
  todos: Arc<Mutex<HashMap<String, TodoItem>>>,
}

impl TodoService {
  pub fn new() -> Self {
    Self {
      todos: Arc::new(Mutex::new(HashMap::new())),
    }
  }

  pub fn add_todo(&self, todo: TodoItem) -> Result<TodoItem, String> {
    let mut todos = self.todos.lock().map_err(|e| e.to_string())?;
    todos.insert(todo.id.clone(), todo.clone());
    Ok(todo)
  }

  pub fn update_todo(&self, id: &str, todo: TodoItem) -> Result<Option<TodoItem>, String> {
    let mut todos = self.todos.lock().map_err(|e| e.to_string())?;
    if todos.contains_key(id) {
      let updated = todo.clone();
      todos.insert(id.to_string(), updated.clone());
      Ok(Some(updated))
    } else {
      Ok(None)
    }
  }

  pub fn delete_todo(&self, id: &str) -> Result<bool, String> {
    let mut todos = self.todos.lock().map_err(|e| e.to_string())?;
    Ok(todos.remove(id).is_some())
  }

  pub fn list_todos(&self) -> Result<Vec<TodoItem>, String> {
    let todos = self.todos.lock().map_err(|e| e.to_string())?;
    let mut items: Vec<TodoItem> = todos.values().cloned().collect();
    items.sort_by(|a, b| b.created_at.cmp(&a.created_at));
    Ok(items)
  }

  pub fn get_todo(&self, id: &str) -> Result<Option<TodoItem>, String> {
    let todos = self.todos.lock().map_err(|e| e.to_string())?;
    Ok(todos.get(id).cloned())
  }
}
