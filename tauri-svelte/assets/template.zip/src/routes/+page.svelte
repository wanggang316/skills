<script lang="ts">
  import { t } from "$lib/i18n";
  import IconButton from "$lib/components/ui/IconButton.svelte";
  import HomeHeader from "$lib/components/HomeHeader.svelte";
  import AddModal from "$lib/components/AddModal.svelte";
  import { Check, Edit2, Trash2 } from "@lucide/svelte";
  import type { TodoItem } from "$lib/api";
  import { addTodo, updateTodo, deleteTodo, listTodos } from "$lib/api";

  let todos = $state<TodoItem[]>([]);
  let loading = $state(true);
  let modalOpen = $state(false);
  let editingTodo = $state<TodoItem | null>(null);

  $effect(() => {
    loadTodos();
  });

  const loadTodos = async (silent = false) => {
    if (!silent) loading = true;
    try {
      todos = await listTodos();
    } catch (error) {
      console.error("Failed to load todos:", error);
    } finally {
      if (!silent) loading = false;
    }
  };

  const handleAddTodo = async (todo: Omit<TodoItem, "created_at" | "updated_at">) => {
    try {
      await addTodo(todo);
      await loadTodos(true);
      closeModal();
    } catch (error) {
      console.error("Failed to add todo:", error);
    }
  };

  const handleUpdateTodo = async (item: TodoItem) => {
    try {
      const updated = await updateTodo(item);
      if (updated) {
        await loadTodos(true);
        closeModal();
      }
    } catch (error) {
      console.error("Failed to update todo:", error);
    }
  };

  const handleDeleteTodo = async (id: string) => {
    try {
      await deleteTodo(id);
      await loadTodos(true);
    } catch (error) {
      console.error("Failed to delete todo:", error);
    }
  };

  const toggleComplete = async (item: TodoItem) => {
    try {
      await updateTodo({ ...item, completed: !item.completed });
      await loadTodos(true);
    } catch (error) {
      console.error("Failed to toggle todo:", error);
    }
  };

  const openEditModal = (item: TodoItem) => {
    editingTodo = item;
    modalOpen = true;
  };

  const closeModal = () => {
    modalOpen = false;
    editingTodo = null;
  };
</script>

<div class="bg-base-100 text-base-content flex h-screen flex-col overflow-hidden">
  <header class="bg-base-100 border-base-200 border-b">
    <HomeHeader onAdd={() => { editingTodo = null; modalOpen = true; }} />
  </header>

  <main class="flex-1 overflow-y-auto">
    <div class="mx-auto max-w-2xl px-4 py-4">
      {#if loading}
        <div class="flex items-center justify-center py-12">
          <p class="text-base-content-muted text-sm">{$t("todo.loading")}</p>
        </div>
      {:else if todos.length === 0}
        <div class="bg-base-200 rounded-xl p-12 text-center">
          <p class="text-base-content-muted text-sm mb-4">{$t("todo.empty")}</p>
          <button
            onclick={() => { editingTodo = null; modalOpen = true; }}
            type="button"
            class="bg-primary text-primary-content hover:bg-primary-hover rounded-lg px-6 py-2.5 text-sm font-medium transition-colors"
          >
            {$t("todo.add")}
          </button>
        </div>
      {:else}
        <div class="space-y-3">
          {#each todos as item (item.id)}
            <div class="bg-base-200 hover:bg-base-300 rounded-xl p-4 transition-colors">
              <div class="flex items-center gap-4">
                <button
                  onclick={() => toggleComplete(item)}
                  class="flex-shrink-0"
                  type="button"
                  aria-label={item.completed ? $t("todo.markIncomplete") : $t("todo.markComplete")}
                >
                  {#if item.completed}
                    <div class="bg-success text-success-content rounded-full p-1">
                      <Check size={14} />
                    </div>
                  {:else}
                    <div class="h-5 w-5 rounded-full border-2 border-base-content/50"></div>
                  {/if}
                </button>

                <div class="flex-1 min-w-0">
                  <h3 class="text-base-content text-base font-medium {item.completed ? 'text-base-content-muted line-through' : ''}">
                    {item.title}
                  </h3>
                </div>

                <div class="flex items-center gap-2 flex-shrink-0">
                  <IconButton
                    variant="ghost"
                    onclick={() => openEditModal(item)}
                    title={$t("todo.edit")}
                    ariaLabel={$t("todo.edit")}
                  >
                    <Edit2 size={14} />
                  </IconButton>
                  <IconButton
                    variant="ghost"
                    onclick={() => handleDeleteTodo(item.id)}
                    title={$t("todo.delete")}
                    ariaLabel={$t("todo.delete")}
                  >
                    <Trash2 size={14} />
                  </IconButton>
                </div>
              </div>
            </div>
          {/each}
        </div>
      {/if}
    </div>
  </main>
</div>

<AddModal
  bind:open={modalOpen}
  item={editingTodo}
  onClose={closeModal}
  onSave={(item) => (editingTodo ? handleUpdateTodo({ ...item, created_at: editingTodo.created_at, updated_at: editingTodo.updated_at }) : handleAddTodo(item))}
/>
