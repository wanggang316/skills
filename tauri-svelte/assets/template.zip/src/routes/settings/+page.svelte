<script lang="ts">
  import { t } from "$lib/i18n";
  import { settings, updateSettings } from "$lib/stores/settings";
  import IconButton from "$lib/components/ui/IconButton.svelte";
  import { ChevronRight, ChevronLeft, Loader2, Download } from "@lucide/svelte";
  import { check, type Update } from "@tauri-apps/plugin-updater";
  import { relaunch } from "@tauri-apps/plugin-process";
  import { getVersion } from "@tauri-apps/api/app";
  import type { DownloadEvent } from "@tauri-apps/plugin-updater";

  let checkingUpdate = $state(false);
  let updateMessage = $state("");
  let currentVersion = $state("");
  let hasUpdate = $state(false);
  let latestVersion = $state("");
  let updateInstance = $state<Update | null>(null);
  let isInstalling = $state(false);
  let downloadProgress = $state(0);
  let downloadTotalBytes = $state(0);
  let downloadedBytes = $state(0);

  $effect(() => {
    loadVersion();
  });

  const loadVersion = async () => {
    try {
      currentVersion = await getVersion();
    } catch (error) {
      console.error("Failed to load app version:", error);
    }
  };

  const getErrorMessage = (error: unknown, fallback: string): string => {
    if (error instanceof Error && error.message) return error.message;
    if (typeof error === "string" && error.trim()) return error;
    try {
      const text = JSON.stringify(error);
      return text && text !== "{}" ? text : fallback;
    } catch {
      return fallback;
    }
  };

  const handleCheckUpdate = async () => {
    checkingUpdate = true;
    updateMessage = "";
    hasUpdate = false;
    downloadProgress = 0;
    downloadTotalBytes = 0;
    downloadedBytes = 0;
    try {
      const update = await check();
      if (update) {
        hasUpdate = true;
        latestVersion = update.version;
        updateInstance = update;
      } else {
        updateMessage = $t("settings.noUpdateAvailable");
      }
    } catch (error) {
      updateMessage = $t("settings.updateCheckFailed");
      console.error("Failed to check for update:", error);
    } finally {
      checkingUpdate = false;
    }
  };

  const handleInstallUpdate = async () => {
    if (!updateInstance) return;
    isInstalling = true;
    downloadProgress = 0;
    downloadTotalBytes = 0;
    downloadedBytes = 0;
    try {
      await updateInstance.downloadAndInstall((event: DownloadEvent) => {
        switch (event.event) {
          case "Started":
            downloadTotalBytes = event.data.contentLength ?? 0;
            downloadedBytes = 0;
            downloadProgress = 0;
            break;
          case "Progress":
            downloadedBytes += event.data.chunkLength;
            if (downloadTotalBytes > 0) {
              downloadProgress = Math.min(
                100,
                Math.round((downloadedBytes / downloadTotalBytes) * 100)
              );
            }
            break;
          case "Finished":
            downloadProgress = 100;
            break;
        }
      });
      await relaunch();
    } catch (error) {
      updateMessage = getErrorMessage(error, $t("settings.updateInstallFailed"));
      console.error("Failed to install update:", error);
      isInstalling = false;
    }
  };

  const goBack = () => {
    window.history.back();
  };
</script>

<div class="bg-base-100 text-base-content flex h-screen flex-col overflow-hidden">
  <!-- Header -->
  <header class="border-base-300 bg-base-100 sticky top-0 z-50 border-b">
    <div class="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
      <div class="flex items-center gap-4">
        <IconButton
          variant="outline"
          onclick={goBack}
          title={$t("settings.back")}
          ariaLabel={$t("settings.back")}
        >
          <ChevronLeft size={16} />
        </IconButton>
        <h1 class="text-base-content text-lg font-medium">
          {$t("settings.title")}
        </h1>
      </div>
    </div>
  </header>

  <!-- Content -->
  <main class="flex-1 overflow-y-auto">
    <div class="mx-auto max-w-4xl px-6 py-6">
      <section class="space-y-4">
        <!-- Language & Theme -->
        <div class="bg-base-200 flex flex-col gap-4 rounded-2xl px-4 py-2.5">
          <div class="flex items-center justify-between">
            <span class="text-base-content text-[15px]">{$t("settings.language")}</span>
            <div class="relative">
              <select
                class="bg-base-300 text-base-content hover:bg-base-100 min-w-[120px] cursor-pointer appearance-none rounded-lg px-3 py-1.5 pr-9 text-right text-[14px] transition-colors focus:outline-none"
                value={$settings.language}
                onchange={(event) =>
                  updateSettings({
                    language: event.currentTarget.value as import("$lib/api/settings").AppSettings["language"],
                  })}
              >
                <option value="en">English</option>
                <option value="zh">中文</option>
              </select>
              <ChevronRight
                class="text-base-content-muted pointer-events-none absolute top-1/2 right-2.5 -translate-y-1/2 rotate-90"
                size={14}
              />
            </div>
          </div>

          <div class="bg-base-300 h-px"></div>

          <div class="flex items-center justify-between">
            <span class="text-base-content text-[15px]">{$t("settings.theme")}</span>
            <div class="relative">
              <select
                class="bg-base-300 text-base-content hover:bg-base-100 min-w-[120px] cursor-pointer appearance-none rounded-lg px-3 py-1.5 pr-9 text-right text-[14px] transition-colors focus:outline-none"
                value={$settings.theme}
                onchange={(event) =>
                  updateSettings({
                    theme: event.currentTarget.value as import("$lib/api/settings").AppSettings["theme"],
                  })}
              >
                <option value="system">{$t("settings.theme.system")}</option>
                <option value="light">{$t("settings.theme.light")}</option>
                <option value="dark">{$t("settings.theme.dark")}</option>
              </select>
              <ChevronRight
                class="text-base-content-muted pointer-events-none absolute top-1/2 right-2.5 -translate-y-1/2 rotate-90"
                size={14}
              />
            </div>
          </div>
        </div>

        <!-- Updates -->
        <div class="bg-base-200 rounded-2xl px-4 py-2.5">
          <div class="flex items-center justify-between">
            <div class="flex flex-col">
              <span class="text-base-content text-[15px]">{$t("settings.about")}</span>
              {#if currentVersion}
                <span class="text-base-content-muted text-xs">
                  {$t("settings.currentVersion", { version: currentVersion })}
                </span>
              {/if}
            </div>
            {#if hasUpdate}
              <div class="flex items-center gap-2">
                <span class="text-success text-xs font-medium">
                  {$t("settings.newVersionAvailable", { version: latestVersion })}
                </span>
                <button
                  class="bg-success text-success-content hover:bg-primary-hover flex items-center rounded-lg px-3 py-1.5 text-[13px] disabled:opacity-50"
                  onclick={handleInstallUpdate}
                  disabled={isInstalling}
                  type="button"
                >
                  {#if isInstalling}
                    <Loader2 size={13} class="mr-1.5 animate-spin" />
                  {:else}
                    <Download size={13} class="mr-1.5" />
                  {/if}
                  {isInstalling ? $t("settings.installingUpdate") : $t("settings.installUpdate")}
                </button>
              </div>
            {:else}
              <button
                class="bg-primary text-primary-content hover:bg-primary-hover rounded-lg px-3 py-1.5 text-[13px] disabled:opacity-50"
                onclick={handleCheckUpdate}
                disabled={checkingUpdate}
                type="button"
              >
                {checkingUpdate ? $t("settings.checkingUpdate") : $t("settings.checkUpdateBtn")}
              </button>
            {/if}
          </div>
          {#if updateMessage}
            <span class="text-base-content-muted mt-1.5 block text-xs">{updateMessage}</span>
          {/if}
        </div>
      </section>
    </div>
  </main>
</div>
