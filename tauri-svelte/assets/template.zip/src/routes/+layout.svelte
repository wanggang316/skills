<script lang="ts">
  import "../app.css";
  import { onMount } from "svelte";
  import { loadSettings } from "$lib/stores/settings";
  import { ensureUpdateChecked } from "$lib/stores/updater";

  let { children } = $props();

  onMount(() => {
    loadSettings().catch(console.error);
    ensureUpdateChecked().catch(console.error);
  });
</script>

{@render children()}
