import { derived } from "svelte/store";
import { settings } from "$lib/stores/settings";

type Dictionary = Record<string, string>;

const translations: Record<string, Dictionary> = {
  en: {
    "app.title": "Tauri App",
    "app.desc": "Reusable capabilities only",
    "common.back": "Back",
    "common.close": "Close",
    "common.cancel": "Cancel",
    "common.save": "Save",
    "common.add": "Add",
    "settings.title": "Settings",
    "settings.back": "Back",
    "settings.language": "Language",
    "settings.theme": "Theme",
    "settings.theme.system": "System",
    "settings.theme.light": "Light",
    "settings.theme.dark": "Dark",
    "settings.about": "About",
    "settings.currentVersion": "Version {version}",
    "settings.noUpdateAvailable": "No updates available",
    "settings.updateCheckFailed": "Failed to check for updates",
    "settings.newVersionAvailable": "New version available: {version}",
    "settings.checkUpdateBtn": "Check for updates",
    "settings.checkingUpdate": "Checking...",
    "settings.installUpdate": "Install update",
    "settings.installingUpdate": "Installing...",
    "settings.updateInstallFailed": "Failed to install update",
    "todo.title": "Todo List",
    "todo.add": "Add Todo",
    "todo.edit": "Edit",
    "todo.delete": "Delete",
    "todo.loading": "Loading...",
    "todo.empty": "No todos yet. Add your first one!",
    "todo.titlePlaceholder": "What needs to be done?",
    "todo.completed": "Completed",
    "todo.markComplete": "Mark as complete",
    "todo.markIncomplete": "Mark as incomplete",
  },
  zh: {
    "app.title": "Tauri App",
    "app.desc": "仅保留公共能力",
    "common.back": "返回",
    "common.close": "关闭",
    "common.cancel": "取消",
    "common.save": "保存",
    "common.add": "添加",
    "settings.title": "设置",
    "settings.back": "返回",
    "settings.language": "语言",
    "settings.theme": "主题",
    "settings.theme.system": "跟随系统",
    "settings.theme.light": "浅色",
    "settings.theme.dark": "深色",
    "settings.about": "关于",
    "settings.currentVersion": "版本 {version}",
    "settings.noUpdateAvailable": "已是最新版本",
    "settings.updateCheckFailed": "检查更新失败",
    "settings.newVersionAvailable": "新版本可用：{version}",
    "settings.checkUpdateBtn": "检查更新",
    "settings.checkingUpdate": "检查中...",
    "settings.installUpdate": "安装更新",
    "settings.installingUpdate": "安装中...",
    "settings.updateInstallFailed": "安装更新失败",
    "todo.title": "待办事项",
    "todo.add": "添加",
    "todo.edit": "编辑",
    "todo.delete": "删除",
    "todo.loading": "加载中...",
    "todo.empty": "暂无待办事项，添加第一条吧！",
    "todo.titlePlaceholder": "需要做什么？",
    "todo.completed": "已完成",
    "todo.markComplete": "标记为已完成",
    "todo.markIncomplete": "标记为未完成",
  },
};

export const t = derived(settings, ($settings) => {
  const language = $settings.language || "en";
  const dict = translations[language] || translations.en;
  return (key: string, params: Record<string, string | number> = {}) => {
    const template = dict[key] || translations.en[key] || key;
    return template.replace(/\{(\w+)\}/g, (_, name) =>
      params[name] === undefined ? "" : String(params[name])
    );
  };
});
