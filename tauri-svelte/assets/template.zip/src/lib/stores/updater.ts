import { get, writable } from "svelte/store";
import { check, type Update } from "@tauri-apps/plugin-updater";
import { relaunch } from "@tauri-apps/plugin-process";

export const updaterState = writable<{ update: Update | null }>({ update: null });

export async function ensureUpdateChecked(): Promise<void> {
  const update = await check().catch(() => null);
  updaterState.set({ update: update ?? null });
}

export async function installAvailableUpdate(): Promise<void> {
  const target = get(updaterState).update;
  if (!target) return;
  await target.downloadAndInstall();
  await relaunch();
}
