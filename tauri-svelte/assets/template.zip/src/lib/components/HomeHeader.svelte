<script lang="ts">
  import { t } from "$lib/i18n";
  import { Settings, Plus, Layers } from "@lucide/svelte";

  interface Props {
    onAdd?: () => void;
  }

  let { onAdd }: Props = $props();
</script>

<div class="flex items-center justify-between px-8 py-3">
  <div class="text-base-content flex items-center gap-2">
    <svg width="28" viewBox="0 0 433 455" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path
        d="M0 263.506L265.588 0L205.547 180.705H433L153.889 455L217.987 263.506H0Z"
        fill="currentColor"
      />
    </svg>
    <p class="text-lg italic">{$t("app.title")}</p>
  </div>

  <div class="flex items-center gap-1">
    {#if onAdd}
      <button
        onclick={onAdd}
        type="button"
        class="text-base-content hover:bg-base-200 rounded-xl p-2 transition-colors"
        aria-label={$t("todo.add")}
        title={$t("todo.add")}
      >
        <Plus size={20} />
      </button>
    {/if}
    <a
      href="/settings"
      class="text-base-content hover:bg-base-200 rounded-xl p-2 transition-colors"
      aria-label={$t("settings.title")}
      title={$t("settings.title")}
    >
      <Settings size={20} />
    </a>
  </div>
</div>
