<script lang="ts">
  import { t } from "$lib/i18n";
  import type { TodoItem } from "$lib/api";
  import Modal from "$lib/components/ui/Modal.svelte";
  import PrimaryActionButton from "$lib/components/ui/PrimaryActionButton.svelte";

  interface Props {
    open?: boolean;
    item: TodoItem | null;
    onClose: () => void;
    onSave: (item: Omit<TodoItem, "created_at" | "updated_at">) => void;
  }

  let { open = $bindable(false), item, onClose, onSave }: Props = $props();

  let title = $state("");
  let completed = $state(false);

  $effect(() => {
    if (open) {
      title = item?.title || "";
      completed = item?.completed || false;
    }
  });

  const handleSave = () => {
    if (title.trim()) {
      onSave({
        id: item?.id || crypto.randomUUID(),
        title: title.trim(),
        completed,
      });
    }
  };
</script>

<Modal
  bind:open
  title={item ? $t("todo.edit") : $t("todo.add")}
  onClose={onClose}
  closeOnBackdropClick={true}
  containerClass="max-w-md"
>
  <div class="p-6 space-y-4">
    <div>
      <label for="todo-title" class="text-base-content block text-sm font-medium mb-2">
        {$t("todo.title")}
      </label>
      <input
        id="todo-title"
        type="text"
        bind:value={title}
        placeholder={$t("todo.titlePlaceholder")}
        class="bg-base-100 text-base-content dark:bg-base-800 w-full rounded-lg border border-base-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary"
        onkeydown={(e) => e.key === "Enter" && handleSave()}
      />
    </div>

    <label class="text-base-content flex items-center gap-2 cursor-pointer">
      <input
        type="checkbox"
        bind:checked={completed}
        class="h-5 w-5 rounded border-base-300 text-primary focus:ring-primary"
      />
      <span class="text-sm">{$t("todo.completed")}</span>
    </label>
  </div>

  {#snippet footer()}
    <button
      onclick={onClose}
      type="button"
      class="text-base-content hover:bg-base-300 dark:hover:bg-base-800 rounded-lg px-5 py-2.5 text-sm font-medium transition-colors"
    >
      {$t("common.cancel")}
    </button>
    <PrimaryActionButton onclick={handleSave} disabled={!title.trim()}>
      {item ? $t("common.save") : $t("common.add")}
    </PrimaryActionButton>
  {/snippet}
</Modal>
