/**
 * Settings API
 *
 * 处理应用设置相关的 IPC 调用
 */

import { apiCall } from "./index";

export interface AppSettings {
  language: "en" | "zh";
  theme: "system" | "light" | "dark";
}

/**
 * 获取应用设置
 */
export async function getSettings(): Promise<AppSettings> {
  return apiCall<AppSettings>("get_settings");
}

/**
 * 更新应用设置
 */
export async function updateSettings(
  settings: Pick<AppSettings, "language" | "theme">
): Promise<AppSettings> {
  return apiCall<AppSettings>("update_settings", { settings });
}
