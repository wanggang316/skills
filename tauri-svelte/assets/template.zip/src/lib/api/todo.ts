import { apiCall } from "./index";

export interface TodoItem {
  id: string;
  title: string;
  completed: boolean;
  created_at: number;
  updated_at: number;
}

export async function addTodo(todo: Omit<TodoItem, "created_at" | "updated_at">): Promise<TodoItem> {
  const now = Date.now();
  return apiCall<TodoItem>("add_todo", {
    todo: {
      ...todo,
      created_at: now,
      updated_at: now,
    },
  });
}

export async function updateTodo(todo: TodoItem): Promise<TodoItem | null> {
  return apiCall<TodoItem | null>("update_todo", {
    todo: { ...todo, updated_at: Date.now() },
  });
}

export async function deleteTodo(id: string): Promise<boolean> {
  return apiCall<boolean>("delete_todo", { id });
}

export async function listTodos(): Promise<TodoItem[]> {
  return apiCall<TodoItem[]>("list_todos");
}

export async function getTodo(id: string): Promise<TodoItem | null> {
  return apiCall<TodoItem | null>("get_todo", { id });
}
